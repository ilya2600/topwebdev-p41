



//alert("hello world!!!");


function confirmFunc() {
    if (confirm("Выбрать ок или отмена.")) {
        window.document.getElementById("text").innerHTML = "CONFIRMED"
    } else {
        window.document.getElementById("text").innerHTML = "CANCELLED"
    }
}

//alert(window.document.getElementById("text").innerHTML);


function showParagraph(){
    document.getElementById("text2").style.display = "block";
}

function hideParagraph(){
    document.getElementById("text2").style.display = "none";
}

function toggleVisibility(){
    if(document.getElementById("text2").style.display === "none"){
        showParagraph();
    } else{
        hideParagraph();
    }
}