function performSearch() {
    console.log("Performing search...")
}
